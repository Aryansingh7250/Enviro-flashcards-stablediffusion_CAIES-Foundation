import React, { useState } from 'react';
import { Header } from './components/Header';
import { TopicSelector } from './components/TopicSelector';
import { PromptEditor } from './components/PromptEditor';
import { FlashcardPreview } from './components/FlashcardPreview';
import { BatchGenerator } from './components/BatchGenerator';
import { PromptHistory } from './components/PromptHistory';
import { ExportPanel } from './components/ExportPanel';
import { FlashcardProvider } from './context/FlashcardContext';

function App() {
  const [activeTab, setActiveTab] = useState<'generate' | 'batch' | 'history' | 'export'>('generate');

  return (
    <FlashcardProvider>
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-teal-50">
        <Header />
        
        <main className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <nav className="flex space-x-1 bg-white/70 backdrop-blur-sm p-1 rounded-xl shadow-lg">
              {[
                { id: 'generate', label: 'Generate', desc: 'Create flashcards' },
                { id: 'batch', label: 'Batch', desc: 'Bulk generation' },
                { id: 'history', label: 'History', desc: 'Past generations' },
                { id: 'export', label: 'Export', desc: 'Download & share' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex-1 px-4 py-3 rounded-lg font-medium transition-all duration-200 ${
                    activeTab === tab.id
                      ? 'bg-green-500 text-white shadow-lg transform scale-105'
                      : 'text-gray-600 hover:bg-white/60 hover:text-gray-800'
                  }`}
                >
                  <div className="text-sm font-semibold">{tab.label}</div>
                  <div className="text-xs opacity-75">{tab.desc}</div>
                </button>
              ))}
            </nav>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {activeTab === 'generate' && (
              <>
                <div className="lg:col-span-2 space-y-6">
                  <TopicSelector />
                  <PromptEditor />
                </div>
                <div className="space-y-6">
                  <FlashcardPreview />
                </div>
              </>
            )}
            
            {activeTab === 'batch' && (
              <div className="lg:col-span-3">
                <BatchGenerator />
              </div>
            )}
            
            {activeTab === 'history' && (
              <div className="lg:col-span-3">
                <PromptHistory />
              </div>
            )}
            
            {activeTab === 'export' && (
              <div className="lg:col-span-3">
                <ExportPanel />
              </div>
            )}
          </div>
        </main>
      </div>
    </FlashcardProvider>
  );
}

export default App;