import React, { createContext, useContext, useState, ReactNode } from 'react';

interface Flashcard {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  prompt: string;
  topic: string;
  timestamp: string;
}

interface FlashcardContextType {
  selectedTopic: string;
  setSelectedTopic: (topic: string) => void;
  currentPrompt: string;
  setCurrentPrompt: (prompt: string) => void;
  currentFlashcard: Flashcard | null;
  setCurrentFlashcard: (flashcard: Flashcard | null) => void;
  generateFlashcard: (prompt: string, style: string) => Promise<void>;
  flashcards: Flashcard[];
  setFlashcards: (flashcards: Flashcard[]) => void;
}

const FlashcardContext = createContext<FlashcardContextType | undefined>(undefined);

export const useFlashcardContext = () => {
  const context = useContext(FlashcardContext);
  if (context === undefined) {
    throw new Error('useFlashcardContext must be used within a FlashcardProvider');
  }
  return context;
};

// Mock images for demonstration
const mockImages = {
  biodiversity: [
    'https://images.pexels.com/photos/847393/pexels-photo-847393.jpeg?auto=compress&cs=tinysrgb&w=800',
    'https://images.pexels.com/photos/1084540/pexels-photo-1084540.jpeg?auto=compress&cs=tinysrgb&w=800',
    'https://images.pexels.com/photos/1831234/pexels-photo-1831234.jpeg?auto=compress&cs=tinysrgb&w=800'
  ],
  pollution: [
    'https://images.pexels.com/photos/3675467/pexels-photo-3675467.jpeg?auto=compress&cs=tinysrgb&w=800',
    'https://images.pexels.com/photos/2850281/pexels-photo-2850281.jpeg?auto=compress&cs=tinysrgb&w=800',
    'https://images.pexels.com/photos/2382894/pexels-photo-2382894.jpeg?auto=compress&cs=tinysrgb&w=800'
  ],
  climate: [
    'https://images.pexels.com/photos/1127611/pexels-photo-1127611.jpeg?auto=compress&cs=tinysrgb&w=800',
    'https://images.pexels.com/photos/1108572/pexels-photo-1108572.jpeg?auto=compress&cs=tinysrgb&w=800',
    'https://images.pexels.com/photos/1076758/pexels-photo-1076758.jpeg?auto=compress&cs=tinysrgb&w=800'
  ],
  energy: [
    'https://images.pexels.com/photos/433308/pexels-photo-433308.jpeg?auto=compress&cs=tinysrgb&w=800',
    'https://images.pexels.com/photos/421888/pexels-photo-421888.jpeg?auto=compress&cs=tinysrgb&w=800',
    'https://images.pexels.com/photos/2800832/pexels-photo-2800832.jpeg?auto=compress&cs=tinysrgb&w=800'
  ]
};

export const FlashcardProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [selectedTopic, setSelectedTopic] = useState<string>('biodiversity');
  const [currentPrompt, setCurrentPrompt] = useState<string>('');
  const [currentFlashcard, setCurrentFlashcard] = useState<Flashcard | null>(null);
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);

  const generateFlashcard = async (prompt: string, style: string): Promise<void> => {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Get random image based on topic
    const topicImages = mockImages[selectedTopic as keyof typeof mockImages] || mockImages.biodiversity;
    const randomImage = topicImages[Math.floor(Math.random() * topicImages.length)];
    
    // Generate title and description based on prompt
    const title = prompt.split(' ').slice(0, 4).join(' ');
    const description = `AI-generated visualization exploring ${selectedTopic} concepts through ${style} imagery.`;
    
    const newFlashcard: Flashcard = {
      id: Date.now().toString(),
      title,
      description,
      imageUrl: randomImage,
      prompt,
      topic: selectedTopic,
      timestamp: new Date().toISOString()
    };
    
    setCurrentFlashcard(newFlashcard);
    setFlashcards(prev => [newFlashcard, ...prev]);
  };

  const value: FlashcardContextType = {
    selectedTopic,
    setSelectedTopic,
    currentPrompt,
    setCurrentPrompt,
    currentFlashcard,
    setCurrentFlashcard,
    generateFlashcard,
    flashcards,
    setFlashcards
  };

  return (
    <FlashcardContext.Provider value={value}>
      {children}
    </FlashcardContext.Provider>
  );
};