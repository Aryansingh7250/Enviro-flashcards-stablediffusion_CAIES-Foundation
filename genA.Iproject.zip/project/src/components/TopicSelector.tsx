import React from 'react';
import { useFlashcardContext } from '../context/FlashcardContext';
import { TreePine, Droplets, Sun, Recycle, Fish, Wind, Factory, Zap } from 'lucide-react';

const topics = [
  { id: 'biodiversity', label: 'Biodiversity', icon: Fish, color: 'bg-blue-500', desc: 'Wildlife and ecosystems' },
  { id: 'pollution', label: 'Pollution', icon: Factory, color: 'bg-red-500', desc: 'Air, water, and soil contamination' },
  { id: 'climate', label: 'Climate Change', icon: Sun, color: 'bg-orange-500', desc: 'Global warming and impacts' },
  { id: 'energy', label: 'Clean Energy', icon: Zap, color: 'bg-yellow-500', desc: 'Renewable energy sources' },
  { id: 'conservation', label: 'Conservation', icon: TreePine, color: 'bg-green-500', desc: 'Protecting natural resources' },
  { id: 'water', label: 'Water Resources', icon: Droplets, color: 'bg-cyan-500', desc: 'Water management and protection' },
  { id: 'waste', label: 'Waste Management', icon: Recycle, color: 'bg-purple-500', desc: 'Recycling and waste reduction' },
  { id: 'sustainability', label: 'Sustainability', icon: Wind, color: 'bg-teal-500', desc: 'Sustainable practices' }
];

export const TopicSelector: React.FC = () => {
  const { selectedTopic, setSelectedTopic } = useFlashcardContext();

  return (
    <div className="bg-white/70 backdrop-blur-sm rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4">Environmental Topics</h2>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {topics.map((topic) => {
          const Icon = topic.icon;
          const isSelected = selectedTopic === topic.id;
          
          return (
            <button
              key={topic.id}
              onClick={() => setSelectedTopic(topic.id)}
              className={`p-4 rounded-lg border-2 transition-all duration-200 hover:scale-105 ${
                isSelected
                  ? `${topic.color} border-transparent text-white shadow-lg`
                  : 'bg-white border-gray-200 text-gray-700 hover:border-gray-300'
              }`}
            >
              <Icon className={`w-6 h-6 mx-auto mb-2 ${isSelected ? 'text-white' : 'text-gray-600'}`} />
              <div className="text-sm font-medium">{topic.label}</div>
              <div className={`text-xs mt-1 ${isSelected ? 'text-white/80' : 'text-gray-500'}`}>
                {topic.desc}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};