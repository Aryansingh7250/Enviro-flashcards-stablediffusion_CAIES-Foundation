import React from 'react';
import { Clock, Star, Copy, Download, Filter } from 'lucide-react';

const historyItems = [
  {
    id: '1',
    prompt: 'Coral reef bleaching due to ocean warming',
    topic: 'biodiversity',
    timestamp: '2025-01-10T10:30:00Z',
    imageUrl: 'https://images.pexels.com/photos/847393/pexels-photo-847393.jpeg?auto=compress&cs=tinysrgb&w=400',
    favorite: true,
    downloads: 15
  },
  {
    id: '2',
    prompt: 'Wind turbines generating clean energy at sunset',
    topic: 'energy',
    timestamp: '2025-01-10T09:15:00Z',
    imageUrl: 'https://images.pexels.com/photos/433308/pexels-photo-433308.jpeg?auto=compress&cs=tinysrgb&w=400',
    favorite: false,
    downloads: 8
  },
  {
    id: '3',
    prompt: 'Plastic waste impact on marine ecosystem',
    topic: 'pollution',
    timestamp: '2025-01-10T08:45:00Z',
    imageUrl: 'https://images.pexels.com/photos/3675467/pexels-photo-3675467.jpeg?auto=compress&cs=tinysrgb&w=400',
    favorite: true,
    downloads: 22
  },
  {
    id: '4',
    prompt: 'Deforestation effects on wildlife habitats',
    topic: 'biodiversity',
    timestamp: '2025-01-09T16:20:00Z',
    imageUrl: 'https://images.pexels.com/photos/1084540/pexels-photo-1084540.jpeg?auto=compress&cs=tinysrgb&w=400',
    favorite: false,
    downloads: 12
  }
];

export const PromptHistory: React.FC = () => {
  const [filter, setFilter] = React.useState<'all' | 'favorites'>('all');
  const [sortBy, setSortBy] = React.useState<'newest' | 'oldest' | 'popular'>('newest');

  const filteredItems = historyItems
    .filter(item => filter === 'all' || item.favorite)
    .sort((a, b) => {
      if (sortBy === 'newest') return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
      if (sortBy === 'oldest') return new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime();
      return b.downloads - a.downloads;
    });

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="bg-white/70 backdrop-blur-sm rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-gray-800">Generation History</h2>
        
        <div className="flex items-center space-x-3">
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value as 'all' | 'favorites')}
            className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            <option value="all">All Items</option>
            <option value="favorites">Favorites Only</option>
          </select>
          
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'newest' | 'oldest' | 'popular')}
            className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="popular">Most Downloaded</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.map((item) => (
          <div key={item.id} className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-200">
            <div className="relative">
              <img
                src={item.imageUrl}
                alt={item.prompt}
                className="w-full h-48 object-cover"
              />
              <div className="absolute top-3 right-3 flex space-x-2">
                <button className={`p-2 rounded-full backdrop-blur-sm ${
                  item.favorite ? 'bg-red-500 text-white' : 'bg-white/80 text-gray-700'
                }`}>
                  <Star className="w-4 h-4" />
                </button>
              </div>
            </div>
            
            <div className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className={`px-2 py-1 text-xs font-medium rounded ${
                  item.topic === 'biodiversity' ? 'bg-blue-100 text-blue-700' :
                  item.topic === 'pollution' ? 'bg-red-100 text-red-700' :
                  item.topic === 'energy' ? 'bg-yellow-100 text-yellow-700' :
                  'bg-green-100 text-green-700'
                }`}>
                  {item.topic}
                </span>
                <div className="flex items-center space-x-1 text-xs text-gray-500">
                  <Clock className="w-3 h-3" />
                  <span>{formatDate(item.timestamp)}</span>
                </div>
              </div>
              
              <p className="text-sm text-gray-700 mb-3 line-clamp-2">{item.prompt}</p>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-1 text-xs text-gray-500">
                  <Download className="w-3 h-3" />
                  <span>{item.downloads} downloads</span>
                </div>
                
                <div className="flex space-x-2">
                  <button className="p-1 text-gray-600 hover:text-gray-800 transition-colors duration-200">
                    <Copy className="w-4 h-4" />
                  </button>
                  <button className="p-1 text-gray-600 hover:text-gray-800 transition-colors duration-200">
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {filteredItems.length === 0 && (
        <div className="text-center py-12 text-gray-500">
          <div className="w-16 h-16 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center">
            <Filter className="w-8 h-8 text-gray-400" />
          </div>
          <p>No items match your current filters</p>
        </div>
      )}
    </div>
  );
};