import React, { useState } from 'react';
import { Play, Pause, Square, Plus, Trash2, Settings } from 'lucide-react';

interface BatchItem {
  id: string;
  prompt: string;
  topic: string;
  status: 'pending' | 'generating' | 'completed' | 'error';
  progress: number;
}

export const BatchGenerator: React.FC = () => {
  const [batchItems, setBatchItems] = useState<BatchItem[]>([
    { id: '1', prompt: 'Deforestation impact on wildlife habitats', topic: 'biodiversity', status: 'pending', progress: 0 },
    { id: '2', prompt: 'Ocean plastic pollution affecting marine life', topic: 'pollution', status: 'pending', progress: 0 },
    { id: '3', prompt: 'Solar panel installation in desert environment', topic: 'energy', status: 'pending', progress: 0 }
  ]);
  const [isProcessing, setIsProcessing] = useState(false);

  const addBatchItem = () => {
    const newItem: BatchItem = {
      id: Date.now().toString(),
      prompt: '',
      topic: 'biodiversity',
      status: 'pending',
      progress: 0
    };
    setBatchItems([...batchItems, newItem]);
  };

  const removeBatchItem = (id: string) => {
    setBatchItems(batchItems.filter(item => item.id !== id));
  };

  const updateBatchItem = (id: string, updates: Partial<BatchItem>) => {
    setBatchItems(batchItems.map(item => 
      item.id === id ? { ...item, ...updates } : item
    ));
  };

  const startBatchProcessing = () => {
    setIsProcessing(true);
    // Simulate batch processing
    batchItems.forEach((item, index) => {
      setTimeout(() => {
        updateBatchItem(item.id, { status: 'generating', progress: 0 });
        
        // Simulate progress
        let progress = 0;
        const interval = setInterval(() => {
          progress += 10;
          updateBatchItem(item.id, { progress });
          
          if (progress >= 100) {
            updateBatchItem(item.id, { status: 'completed', progress: 100 });
            clearInterval(interval);
            
            // Check if all items are completed
            if (index === batchItems.length - 1) {
              setIsProcessing(false);
            }
          }
        }, 200);
      }, index * 1000);
    });
  };

  return (
    <div className="bg-white/70 backdrop-blur-sm rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-gray-800">Batch Generation</h2>
        <div className="flex items-center space-x-3">
          <button
            onClick={addBatchItem}
            className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
          >
            <Plus className="w-4 h-4" />
            <span>Add Item</span>
          </button>
          <button
            onClick={startBatchProcessing}
            disabled={isProcessing || batchItems.length === 0}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors duration-200"
          >
            <Play className="w-4 h-4" />
            <span>{isProcessing ? 'Processing...' : 'Start Batch'}</span>
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {batchItems.map((item) => (
          <div key={item.id} className="bg-white rounded-lg p-4 border border-gray-200">
            <div className="flex items-center space-x-4">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <select
                    value={item.topic}
                    onChange={(e) => updateBatchItem(item.id, { topic: e.target.value })}
                    disabled={isProcessing}
                    className="px-3 py-1 bg-gray-50 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                  >
                    <option value="biodiversity">Biodiversity</option>
                    <option value="pollution">Pollution</option>
                    <option value="climate">Climate Change</option>
                    <option value="energy">Clean Energy</option>
                  </select>
                  <div className={`px-2 py-1 rounded text-xs font-medium ${
                    item.status === 'pending' ? 'bg-gray-100 text-gray-700' :
                    item.status === 'generating' ? 'bg-blue-100 text-blue-700' :
                    item.status === 'completed' ? 'bg-green-100 text-green-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {item.status}
                  </div>
                </div>
                
                <input
                  type="text"
                  value={item.prompt}
                  onChange={(e) => updateBatchItem(item.id, { prompt: e.target.value })}
                  placeholder="Enter prompt for this flashcard..."
                  disabled={isProcessing}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 disabled:bg-gray-50"
                />
                
                {item.status === 'generating' && (
                  <div className="mt-2">
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-1">
                      <span>Progress</span>
                      <span>{item.progress}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${item.progress}%` }}
                      ></div>
                    </div>
                  </div>
                )}
              </div>
              
              <button
                onClick={() => removeBatchItem(item.id)}
                disabled={isProcessing}
                className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors duration-200 disabled:opacity-50"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
        
        {batchItems.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            <div className="w-16 h-16 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center">
              <Settings className="w-8 h-8 text-gray-400" />
            </div>
            <p>No batch items yet. Add some prompts to get started!</p>
          </div>
        )}
      </div>
    </div>
  );
};