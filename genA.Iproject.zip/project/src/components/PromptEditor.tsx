import React, { useState } from 'react';
import { useFlashcardContext } from '../context/FlashcardContext';
import { Wand2, Copy, RefreshCw, Save, Lightbulb } from 'lucide-react';

const promptTemplates = {
  biodiversity: [
    "A vibrant coral reef ecosystem teeming with colorful fish and marine life",
    "Endangered species in their natural habitat showing conservation efforts",
    "A diverse forest ecosystem with various plants and animals coexisting"
  ],
  pollution: [
    "Industrial smokestacks releasing pollution into clear blue sky",
    "Plastic waste floating in ocean waters with marine life",
    "Before and after comparison of environmental cleanup efforts"
  ],
  climate: [
    "Melting glaciers and rising sea levels affecting coastal communities",
    "Extreme weather events showing climate change impacts",
    "Solar panels and wind turbines in a sustainable energy landscape"
  ],
  energy: [
    "Modern solar farm with panels reflecting sunlight",
    "Wind turbines on rolling hills generating clean energy",
    "Hydroelectric dam harnessing water power sustainably"
  ]
};

export const PromptEditor: React.FC = () => {
  const { selectedTopic, currentPrompt, setCurrentPrompt, generateFlashcard } = useFlashcardContext();
  const [isGenerating, setIsGenerating] = useState(false);
  const [style, setStyle] = useState('photorealistic');

  const handleGenerate = async () => {
    if (!currentPrompt.trim()) return;
    
    setIsGenerating(true);
    await generateFlashcard(currentPrompt, style);
    setIsGenerating(false);
  };

  const useTemplate = (template: string) => {
    setCurrentPrompt(template);
  };

  const templates = promptTemplates[selectedTopic as keyof typeof promptTemplates] || [];

  return (
    <div className="bg-white/70 backdrop-blur-sm rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-gray-800">Prompt Engineering</h2>
        <div className="flex items-center space-x-2">
          <select
            value={style}
            onChange={(e) => setStyle(e.target.value)}
            className="px-3 py-1 bg-white border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            <option value="photorealistic">Photorealistic</option>
            <option value="illustration">Illustration</option>
            <option value="artistic">Artistic</option>
            <option value="infographic">Infographic</option>
          </select>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Describe your environmental flashcard
          </label>
          <textarea
            value={currentPrompt}
            onChange={(e) => setCurrentPrompt(e.target.value)}
            placeholder="Enter a detailed description of the environmental scene or concept you want to visualize..."
            className="w-full h-32 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 resize-none"
          />
        </div>

        {templates.length > 0 && (
          <div>
            <div className="flex items-center space-x-2 mb-2">
              <Lightbulb className="w-4 h-4 text-yellow-500" />
              <span className="text-sm font-medium text-gray-700">Template Suggestions</span>
            </div>
            <div className="space-y-2">
              {templates.map((template, index) => (
                <button
                  key={index}
                  onClick={() => useTemplate(template)}
                  className="w-full text-left p-3 bg-gray-50 hover:bg-gray-100 rounded-lg text-sm transition-colors duration-200"
                >
                  {template}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="flex space-x-3">
          <button
            onClick={handleGenerate}
            disabled={!currentPrompt.trim() || isGenerating}
            className="flex-1 flex items-center justify-center space-x-2 px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors duration-200"
          >
            {isGenerating ? (
              <RefreshCw className="w-5 h-5 animate-spin" />
            ) : (
              <Wand2 className="w-5 h-5" />
            )}
            <span>{isGenerating ? 'Generating...' : 'Generate Flashcard'}</span>
          </button>
          
          <button
            onClick={() => navigator.clipboard.writeText(currentPrompt)}
            className="px-4 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors duration-200"
          >
            <Copy className="w-5 h-5" />
          </button>
          
          <button
            className="px-4 py-3 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors duration-200"
          >
            <Save className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};