import React, { useState } from 'react';
import { Download, FileText, Image, Package, Settings, CheckCircle } from 'lucide-react';

export const ExportPanel: React.FC = () => {
  const [exportFormat, setExportFormat] = useState<'png' | 'jpg' | 'pdf' | 'zip'>('png');
  const [exportQuality, setExportQuality] = useState<'high' | 'medium' | 'low'>('high');
  const [includeMetadata, setIncludeMetadata] = useState(true);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);

  const exportOptions = [
    { value: 'png', label: 'PNG Images', icon: Image, desc: 'High quality with transparency' },
    { value: 'jpg', label: 'JPEG Images', icon: Image, desc: 'Smaller file size' },
    { value: 'pdf', label: 'PDF Document', icon: FileText, desc: 'Print-ready format' },
    { value: 'zip', label: 'ZIP Archive', icon: Package, desc: 'All formats bundled' }
  ];

  const recentGenerations = [
    { id: '1', title: 'Coral Reef Bleaching', topic: 'biodiversity', size: '2.4 MB' },
    { id: '2', title: 'Wind Energy Farm', topic: 'energy', size: '1.8 MB' },
    { id: '3', title: 'Ocean Plastic Pollution', topic: 'pollution', size: '3.1 MB' },
    { id: '4', title: 'Forest Conservation', topic: 'biodiversity', size: '2.7 MB' }
  ];

  const handleExport = () => {
    // Export logic would go here
    console.log('Exporting:', { format: exportFormat, quality: exportQuality, items: selectedItems });
  };

  const toggleItemSelection = (id: string) => {
    setSelectedItems(prev => 
      prev.includes(id) 
        ? prev.filter(item => item !== id)
        : [...prev, id]
    );
  };

  const selectAll = () => {
    setSelectedItems(recentGenerations.map(item => item.id));
  };

  const deselectAll = () => {
    setSelectedItems([]);
  };

  return (
    <div className="bg-white/70 backdrop-blur-sm rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-bold text-gray-800 mb-6">Export & Download</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-700 mb-4">Export Format</h3>
            <div className="grid grid-cols-2 gap-3">
              {exportOptions.map((option) => {
                const Icon = option.icon;
                return (
                  <button
                    key={option.value}
                    onClick={() => setExportFormat(option.value as any)}
                    className={`p-4 rounded-lg border-2 transition-all duration-200 ${
                      exportFormat === option.value
                        ? 'border-green-500 bg-green-50 text-green-700'
                        : 'border-gray-200 bg-white hover:border-gray-300'
                    }`}
                  >
                    <Icon className="w-6 h-6 mx-auto mb-2" />
                    <div className="text-sm font-medium">{option.label}</div>
                    <div className="text-xs text-gray-500 mt-1">{option.desc}</div>
                  </button>
                );
              })}
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-gray-700 mb-4">Export Settings</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Image Quality
                </label>
                <select
                  value={exportQuality}
                  onChange={(e) => setExportQuality(e.target.value as any)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                >
                  <option value="high">High Quality (Large files)</option>
                  <option value="medium">Medium Quality (Balanced)</option>
                  <option value="low">Low Quality (Small files)</option>
                </select>
              </div>
              
              <div className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  id="metadata"
                  checked={includeMetadata}
                  onChange={(e) => setIncludeMetadata(e.target.checked)}
                  className="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
                />
                <label htmlFor="metadata" className="text-sm text-gray-700">
                  Include metadata (prompts, timestamps, topics)
                </label>
              </div>
            </div>
          </div>
        </div>
        
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-700">Select Items</h3>
            <div className="flex space-x-2">
              <button
                onClick={selectAll}
                className="text-sm text-green-600 hover:text-green-700 transition-colors duration-200"
              >
                Select All
              </button>
              <button
                onClick={deselectAll}
                className="text-sm text-gray-600 hover:text-gray-700 transition-colors duration-200"
              >
                Deselect All
              </button>
            </div>
          </div>
          
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {recentGenerations.map((item) => (
              <div
                key={item.id}
                className={`p-3 rounded-lg border-2 cursor-pointer transition-all duration-200 ${
                  selectedItems.includes(item.id)
                    ? 'border-green-500 bg-green-50'
                    : 'border-gray-200 bg-white hover:border-gray-300'
                }`}
                onClick={() => toggleItemSelection(item.id)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-4 h-4 rounded border-2 flex items-center justify-center ${
                      selectedItems.includes(item.id)
                        ? 'border-green-500 bg-green-500'
                        : 'border-gray-300'
                    }`}>
                      {selectedItems.includes(item.id) && (
                        <CheckCircle className="w-3 h-3 text-white" />
                      )}
                    </div>
                    <div>
                      <div className="text-sm font-medium text-gray-800">{item.title}</div>
                      <div className="text-xs text-gray-500">{item.topic} • {item.size}</div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6 pt-4 border-t border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <div className="text-sm text-gray-600">
                {selectedItems.length} items selected
              </div>
              <div className="text-sm text-gray-600">
                Estimated size: {(selectedItems.length * 2.5).toFixed(1)} MB
              </div>
            </div>
            
            <button
              onClick={handleExport}
              disabled={selectedItems.length === 0}
              className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors duration-200"
            >
              <Download className="w-5 h-5" />
              <span>Export Selected Items</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};