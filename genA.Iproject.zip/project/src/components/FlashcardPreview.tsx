import React from 'react';
import { useFlashcardContext } from '../context/FlashcardContext';
import { Download, Share2, Heart, RotateCcw } from 'lucide-react';

export const FlashcardPreview: React.FC = () => {
  const { currentFlashcard, currentPrompt } = useFlashcardContext();

  return (
    <div className="bg-white/70 backdrop-blur-sm rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4">Flashcard Preview</h2>
      
      <div className="space-y-4">
        <div className="aspect-square bg-gradient-to-br from-green-100 to-blue-100 rounded-lg overflow-hidden relative">
          {currentFlashcard ? (
            <img
              src={currentFlashcard.imageUrl}
              alt={currentFlashcard.title}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-gray-500">
              <div className="text-center">
                <div className="w-16 h-16 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <div className="w-8 h-8 bg-gray-300 rounded"></div>
                </div>
                <p className="text-sm">Generate a flashcard to see preview</p>
              </div>
            </div>
          )}
          
          {currentFlashcard && (
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4">
              <h3 className="text-white font-bold text-lg">{currentFlashcard.title}</h3>
              <p className="text-white/80 text-sm">{currentFlashcard.description}</p>
            </div>
          )}
        </div>

        {currentFlashcard && (
          <div className="space-y-3">
            <div className="flex space-x-2">
              <button className="flex-1 flex items-center justify-center space-x-2 px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200">
                <Download className="w-4 h-4" />
                <span>Download</span>
              </button>
              <button className="px-3 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors duration-200">
                <Share2 className="w-4 h-4" />
              </button>
              <button className="px-3 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors duration-200">
                <Heart className="w-4 h-4" />
              </button>
            </div>
            
            <div className="text-xs text-gray-600 bg-gray-50 p-3 rounded-lg">
              <strong>Generated from:</strong> {currentPrompt}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};